package com.megacode.zog

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64
import java.util.Locale

private val Bg = Color(0xFF07100D)
private val Panel = Color(0xFF101C17)
private val Green = Color(0xFF35E58A)
private val Muted = Color(0xFF9BB3A6)
private val White = Color(0xFFEAF5EE)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
        }
        setContent {
            ZogApp(
                context = this,
                speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zog-reply") }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

data class ChatMessage(val role: String, val content: String)

@Composable
private fun ZogApp(context: Context, speak: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("zog_local", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }
    var selectedModel by remember { mutableStateOf(prefs.getString("model", "") ?: "") }
    var models by remember { mutableStateOf(listOf<String>()) }
    var messages by remember { mutableStateOf(loadMessages(prefs)) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect your NVIDIA API key to begin.") }
    var showSettings by remember { mutableStateOf(true) }
    var modelMenu by remember { mutableStateOf(false) }
    var speakReplies by remember { mutableStateOf(true) }

    val speechResultLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            }
            speechResultLauncher.launch(intent)
        } else {
            status = "Microphone permission was not granted."
        }
    }

    LaunchedEffect(Unit) {
        apiKey = runCatching { SecureKeyStore(context).read() }.getOrDefault("")
        if (apiKey.isNotBlank()) {
            keyInput = apiKey
            status = "Key loaded securely on this device."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, background = Bg, surface = Panel,
            onPrimary = Bg, onBackground = White, onSurface = White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ZOG", color = Green, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("PERSONAL INTELLIGENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "CHAT" else "SETTINGS", color = Green)
                }
            }

            if (showSettings) {
                Spacer(Modifier.height(14.dp))
                Text("NVIDIA CONNECTION", color = Green, fontWeight = FontWeight.Bold)
                Text("Your key stays encrypted on this Android device.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("NVIDIA API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = fieldColors()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { SecureKeyStore(context).save(keyInput.trim()) }
                                    apiKey = keyInput.trim()
                                    status = "API key saved in Android Keystore encryption."
                                } catch (e: Exception) { status = "Could not save key: ${e.message}" }
                            }
                        },
                        enabled = keyInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
                    ) { Text("SAVE SECURELY") }
                    OutlinedButton(
                        onClick = {
                            if (apiKey.isBlank()) { status = "Save your API key first."; return@OutlinedButton }
                            busy = true
                            scope.launch {
                                try {
                                    val found = withContext(Dispatchers.IO) { NvidiaClient(apiKey).getModels() }
                                    models = found
                                    if (selectedModel.isBlank() && found.isNotEmpty()) selectedModel = found.first()
                                    status = "Connected. ${found.size} models available."
                                } catch (e: Exception) {
                                    status = "Connection failed: ${e.message ?: "Check key and internet."}"
                                } finally { busy = false }
                            }
                        },
                        enabled = apiKey.isNotBlank() && !busy
                    ) { Text("TEST + LOAD MODELS") }
                }
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { modelMenu = true }, enabled = models.isNotEmpty()) {
                        Text(if (selectedModel.isBlank()) "SELECT MODEL" else selectedModel, color = Green)
                    }
                    DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                        models.forEach { model ->
                            DropdownMenuItem(
                                text = { Text(model) },
                                onClick = {
                                    selectedModel = model
                                    prefs.edit().putString("model", model).apply()
                                    modelMenu = false
                                }
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = speakReplies, onCheckedChange = { speakReplies = it })
                    Text("Speak replies aloud", color = Muted, fontSize = 13.sp)
                }
                Text(status, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("NVIDIA NIM uses an OpenAI-compatible chat endpoint. Model access depends on your NVIDIA account and the model's availability.", color = Muted, fontSize = 11.sp)
            } else {
                Text(status, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg ->
                        val isUser = msg.role == "user"
                        Column(
                            Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Text(if (isUser) "YOU" else "ZOG", color = if (isUser) Muted else Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Surface(color = if (isUser) Color(0xFF183528) else Panel, shape = RoundedCornerShape(14.dp)) {
                                Text(msg.content, Modifier.padding(12.dp), color = White, fontSize = 14.sp)
                            }
                        }
                    }
                    if (busy) item { Text("ZOG IS THINKING…", color = Green, fontSize = 12.sp) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask ZOG anything…") },
                        maxLines = 4,
                        colors = fieldColors()
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                            status = "Speech recognition is unavailable on this device."
                        } else {
                            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                }
                                speechResultLauncher.launch(intent)
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }) { Text("🎙", fontSize = 20.sp) }
                    Button(
                        onClick = {
                            val prompt = draft.trim()
                            if (prompt.isEmpty() || busy) return@Button
                            if (apiKey.isBlank() || selectedModel.isBlank()) {
                                status = "Open Settings, save your key, and load/select a model."
                                showSettings = true
                                return@Button
                            }
                            val updated = messages + ChatMessage("user", prompt)
                            messages = updated
                            saveMessages(prefs, updated)
                            draft = ""
                            busy = true
                            status = "Sending securely to NVIDIA…"
                            scope.launch {
                                try {
                                    val answer = withContext(Dispatchers.IO) {
                                        NvidiaClient(apiKey).chat(selectedModel, updated)
                                    }
                                    val next = updated + ChatMessage("assistant", answer)
                                    messages = next
                                    saveMessages(prefs, next)
                                    status = "Online • ${selectedModel}"
                                    if (speakReplies) speak(answer)
                                } catch (e: Exception) {
                                    status = "Request failed: ${e.message ?: "Unknown error"}"
                                } finally { busy = false }
                            }
                        },
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
                    ) { Text("SEND") }
                }
                Row {
                    TextButton(onClick = {
                        messages = emptyList()
                        saveMessages(prefs, emptyList())
                        status = "Conversation cleared on this device."
                    }) { Text("CLEAR CHAT", color = Muted) }
                }
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Green,
    unfocusedBorderColor = Color(0xFF365347),
    focusedLabelColor = Green,
    cursorColor = Green,
    focusedTextColor = White,
    unfocusedTextColor = White
)

private class NvidiaClient(private val key: String) {
    private val base = "https://integrate.api.nvidia.com/v1"

    fun getModels(): List<String> {
        val json = request("$base/models", "GET", null)
        val arr = json.optJSONArray("data") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("id") }
            .filter { it.isNotBlank() }.sorted()
    }

    fun chat(model: String, history: List<ChatMessage>): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put(
            "content",
            "You are ZOG, a capable, honest, helpful personal AI assistant. " +
            "Answer clearly and practically. Do not claim to have performed actions you have not performed. " +
            "Respect human authorization and ask before consequential external actions. " +
            "If uncertain, say so and explain what would verify the answer."
        ))
        history.takeLast(24).forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", model)
            .put("messages", msgs)
            .put("temperature", 0.65)
            .put("max_tokens", 1200)
        val response = request("$base/chat/completions", "POST", body.toString())
        return response.optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content")
            ?.takeIf { it.isNotBlank() } ?: "The model returned an empty response."
    }

    private fun request(urlText: String, method: String, body: String?): JSONObject {
        val conn = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 90000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json")
            if (body != null) doOutput = true
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(text).optString("detail").ifBlank { text.take(500) } }.getOrDefault(text.take(500))
                throw IllegalStateException("NVIDIA HTTP $code: $detail")
            }
            return JSONObject(text)
        } finally { conn.disconnect() }
    }
}

private class SecureKeyStore(private val context: Context) {
    private val alias = "zog_nvidia_api_key_v1"
    private val prefs = context.getSharedPreferences("zog_secrets", Context.MODE_PRIVATE)

    private fun getKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(
            android.security.keystore.KeyGenParameterSpec.Builder(
                alias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun save(value: String) {
        require(value.isNotBlank()) { "API key is empty." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString("nvidia_key", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun read(): String {
        val packed = prefs.getString("nvidia_key", null) ?: return ""
        val bytes = Base64.decode(packed, Base64.NO_WRAP)
        require(bytes.size > 12) { "Stored key data is invalid." }
        val iv = bytes.copyOfRange(0, 12)
        val encrypted = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
    }
}

private fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val arr = JSONArray()
    messages.takeLast(80).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
    prefs.edit().putString("history", arr.toString()).apply()
}

private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
    return runCatching {
        val arr = JSONArray(prefs.getString("history", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { ChatMessage(it.optString("role"), it.optString("content")) }
        }
    }.getOrDefault(emptyList())
}
