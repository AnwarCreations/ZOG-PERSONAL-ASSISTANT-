# ZOG Android — NVIDIA NIM client

A native Android starter app for chatting with NVIDIA-hosted NIM models.

## Included
- Native Kotlin + Jetpack Compose interface with ZOG's dark green visual identity.
- NVIDIA NIM connection at `https://integrate.api.nvidia.com/v1`.
- Fetches model IDs from `GET /models`; user selects a model available to their key.
- Multi-turn chat using `POST /chat/completions`.
- API key encrypted with AES-GCM using a key held by Android Keystore.
- Optional Android text-to-speech replies and speech-to-text input.
- Local chat history and clear-chat control.
- No application backend/server required; requests go directly from the phone to NVIDIA over HTTPS.

## Build with Android Studio
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as an existing project.
3. Let Android Studio sync Gradle and download dependencies.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press **Run**. To make an installable debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Install the generated `app-debug.apk` on your device.

## First launch
1. Open **Settings** in ZOG.
2. Paste your NVIDIA API key into the password field and tap **SAVE SECURELY**.
3. Tap **TEST + LOAD MODELS**.
4. Select an available model from the model menu.
5. Open **CHAT** and send a message.

Never share your API key in chat, screenshots, source code, or a public repository. If it is ever exposed, revoke it and create a replacement in your NVIDIA account.

## API details
NVIDIA documents the hosted NIM chat endpoint as `POST https://integrate.api.nvidia.com/v1/chat/completions`, with bearer-token authentication and an OpenAI-compatible request format. The app queries `GET https://integrate.api.nvidia.com/v1/models` to populate the model picker.

## Important limits
- The app is an AI chat client, not autonomous AGI. It can answer using the selected model's capabilities.
- Internet is required for NVIDIA-hosted inference. API usage, rate limits, model access and any quotas are controlled by NVIDIA and may change.
- Voice input relies on Android's speech-recognition service; availability and network behavior depend on the device/provider. TTS uses Android's installed speech engine.
- The app does not currently browse the web, execute code, control arbitrary devices, or independently take actions. Those require separate, permissioned modules.
- API keys are encrypted at rest with Android Keystore on this device. The key must still be sent to NVIDIA to authenticate each request.
- Chat history is stored locally in app preferences. Avoid entering highly sensitive personal information.
- This source project has not been compiled or device-tested in this environment. Build it in Android Studio before installing; resolve any SDK/dependency sync prompts there.

## Build an APK automatically with GitHub Actions
This project includes `.github/workflows/android.yml`. Push the project to a GitHub repository, then open **Actions → Build ZOG Android APK → Run workflow**. When the workflow succeeds, open its run and download the **ZOG-debug-apk** artifact. This cloud build route supplies the Android SDK and Gradle that are not bundled in this ZIP.
